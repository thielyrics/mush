package mush;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

public class DbInterface {
	private Connection conn;
	
	public DbInterface() {
		try {
			Class.forName("org.sqlite.JDBC");
		} catch (ClassNotFoundException e1) {
			System.err.println("SqliteJDBC library not found. "
					+ "Perhaps you need to set the build path?");
			System.exit(-1);
		}
			
		try {
			conn = DriverManager.getConnection("jdbc:sqlite:mush.db");
		} catch (SQLException e) {
			System.err.println("Could not connect to DBMS. Maybe DBMS isn't running?");
			System.exit(-1);
		}
	}

	public void close() {
		try {
			conn.close();
		} catch (SQLException e) {
			System.err.println("Error closing connection");
		}
	}

	public boolean userExists(String userId) {
		return false;
	}

	public boolean createUser(String userId) {
		return false;
	}

	public Room getCurrentRoom(String userId) {
		return new Room(-1, "You are dead.", "none",
			new ArrayList<String>(), new ArrayList<String>());
	}

	public boolean doAction(String userId, String action) {
		return false;
	}

	public boolean createRoom(String userId, String action, String description) {
		return false;
	}

	public boolean createPassage(String userId, String action, int dst) {
		return false;
	}
}
