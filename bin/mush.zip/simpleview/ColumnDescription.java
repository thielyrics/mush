package simpleview;

class ColumnDescription {
	private String name;

	public ColumnDescription(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
